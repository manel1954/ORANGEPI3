#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_ircddb_off_clicked();

    void on_pushButton_ircddb_on_clicked();

    void on_pushButton_bluedv_on_clicked();

    void on_pushButton_bluedv_off_clicked();

    void on_pushButton_ysf_off_clicked();

    void on_pushButton_ysf_on_clicked();

    void on_pushButton_dv4mini_on_clicked();

    void on_pushButton_dv4mini_off_clicked();

    void on_pushButton_radio_on_clicked();

    void on_pushButton_radio_off_clicked();

    void on_pushButton_dmrplus_on_clicked();

    void on_pushButton_dmrplus_off_clicked();

    void on_pushButton_salir_clicked();

    void on_pushButton_especial_on_clicked();

    void on_pushButton_especial_off_clicked();

    void on_pushButton_bm_on_clicked();

    void on_pushButton_bm_off_clicked();

    void on_pushButton_svxlink_on_clicked();

    void on_pushButton_svxlink_off_clicked();

    void on_pushButton_solodstar_on_clicked();

    void on_pushButton_solodstar_off_clicked();

    void on_pushButton_solofusion_on_clicked();

    void on_pushButton_solofusion_off_clicked();

    void on_pushButton_dvrptr_on_clicked();

    void on_pushButton_dvrptr_off_clicked();

    void on_pushButton_ambe_on_clicked();

    void on_pushButton_ambe_off_clicked();

    void on_pushButton_ysf2dmr_on_clicked();

    void on_pushButton_ysf2dmr_off_clicked();

    void on_pushButton_dmr2ysf_on_clicked();

    void on_pushButton_dmr2ysf_off_clicked();

    void on_pushButton_dmr2nxdn_on_clicked();

    void on_pushButton_dmr2nxdn_off_clicked();

    void on_pushButton_nxdn_on_clicked();

    void on_pushButton_nxdn_off_clicked();

    void on_pushButton_dmrgateway_on_clicked();

    void on_pushButton_dmrgateway_off_clicked();

    void on_pushButton_dmr2m17_on_clicked();

    void on_pushButton_dmr2m17_off_clicked();

    void on_pushButton_m17_on_2_clicked();

    void on_pushButton_dump1090_off_clicked();

    void on_pushButton_dump1090_on_clicked();

    void on_pushButton_dstarrepeater_off_clicked();

    void on_pushButton_dstarrepeater_on_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
