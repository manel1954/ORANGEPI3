#include "mainwindow.h"
#include "ui_mainwindow.h"
//#include "string"
//#include "iostream"
//#include "QTextEdit"
//#include "QLineEdit"
//#include "QObject"
//#include "QLabel"
#include "QString"
#include "QMessageBox"
#include "QFile"
#include "QTextStream"
//#include "QInputDialog"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // la linea siguiente oculta toda la barra superior del formulario
    setWindowFlags(Qt::Window | Qt::CustomizeWindowHint);

    // POSICION DEL FORMULARIO EN LA PANTALLA
    int px  = (1270);
    int py = (425);
    this->move(   QPoint(px,py)  );

    QFile file("/home/orangepi/autoarranque.ini");
    if (!file.open(QIODevice::ReadOnly))
    QMessageBox::information(nullptr,"info", file.errorString());
    QTextStream in(&file);

    //IRCDDB
    ui->label_status_ircddb->setText(in.readLine());

    QString ircddb_status=ui->label_status_ircddb->text();

    if (ircddb_status.contains("D-STAR=ON")){
        ui->pushButton_ircddb_on->setVisible(true);
        ui->pushButton_ircddb_off->setVisible(false);
        ui->label_ircddb_on->setVisible(true);
        ui->label_ircddb_off->setVisible(false);

    }else {
          ui->pushButton_ircddb_off->setVisible(true);
          ui->pushButton_ircddb_on->setVisible(false);
          ui->label_ircddb_on->setVisible(false);
          ui->label_ircddb_off->setVisible(true);
        }
//    //BLUEDV
//    ui->label_status_bluedv->setText(in.readLine());

//    QString bluedv_status=ui->label_status_bluedv->text();

//    if (bluedv_status.contains("DUMP1090=ON")){
//        ui->pushButton_bluedv_on->setVisible(true);
//        ui->pushButton_bluedv_off->setVisible(false);
//        ui->label_bluedv_on->setVisible(true);
//        ui->label_bluedv_off->setVisible(false);

//    }else {
//          ui->pushButton_bluedv_off->setVisible(true);
//          ui->pushButton_bluedv_on->setVisible(false);
//          ui->label_bluedv_on->setVisible(false);
//          ui->label_bluedv_off->setVisible(true);
//        }


    //DUMP1090
    ui->label_status_dump1090->setText(in.readLine());

    QString dump1090_status=ui->label_status_dump1090->text();

    if (dump1090_status.contains("DUMP1090=ON")){
        ui->pushButton_dump1090_on->setVisible(true);
        ui->pushButton_dump1090_off->setVisible(false);
        ui->label_dump1090_on->setVisible(true);
        ui->label_dump1090_off->setVisible(false);

    }else {
          ui->pushButton_dump1090_off->setVisible(true);
          ui->pushButton_dump1090_on->setVisible(false);
          ui->label_dump1090_on->setVisible(false);
          ui->label_dump1090_off->setVisible(true);
        }


    //YSF
    ui->label_status_ysf->setText(in.readLine());

    QString ysf_status=ui->label_status_ysf->text();

    if (ysf_status.contains("C4F=ON")){
        ui->pushButton_ysf_on->setVisible(true);
        ui->pushButton_ysf_off->setVisible(false);
        ui->label_ysf_on->setVisible(true);
        ui->label_ysf_off->setVisible(false);

    }else {
          ui->pushButton_ysf_off->setVisible(true);
          ui->pushButton_ysf_on->setVisible(false);
          ui->label_ysf_on->setVisible(false);
          ui->label_ysf_off->setVisible(true);
        }
    //DV4MINI
    ui->label_status_dv4mini->setText(in.readLine());

    QString dv4mini_status=ui->label_status_dv4mini->text();

    if (dv4mini_status.contains("DV4mini=ON")){
        ui->pushButton_dv4mini_on->setVisible(true);
        ui->pushButton_dv4mini_off->setVisible(false);
        ui->label_dv4mini_on->setVisible(true);
        ui->label_dv4mini_off->setVisible(false);

    }else {
          ui->pushButton_dv4mini_off->setVisible(true);
          ui->pushButton_dv4mini_on->setVisible(false);
          ui->label_dv4mini_on->setVisible(false);
          ui->label_dv4mini_off->setVisible(true);
        }
    //RADIO
    ui->label_status_radio->setText(in.readLine());

    QString radio_status=ui->label_status_radio->text();

    if (radio_status.contains("MMDVMPLACA=ON")){
        ui->pushButton_radio_on->setVisible(true);
        ui->pushButton_radio_off->setVisible(false);
        ui->label_radio_on->setVisible(true);
        ui->label_radio_off->setVisible(false);

    }else {
          ui->pushButton_radio_off->setVisible(true);
          ui->pushButton_radio_on->setVisible(false);
          ui->label_radio_on->setVisible(false);
          ui->label_radio_off->setVisible(true);
        }
    //DMR+
    ui->label_status_dmrplus->setText(in.readLine());

    QString dmrplus_status=ui->label_status_dmrplus->text();

    if (dmrplus_status.contains("MMDVMPLUS=ON")){
        ui->pushButton_dmrplus_on->setVisible(true);
        ui->pushButton_dmrplus_off->setVisible(false);
        ui->label_dmrplus_on->setVisible(true);
        ui->label_dmrplus_off->setVisible(false);

    }else {
          ui->pushButton_dmrplus_off->setVisible(true);
          ui->pushButton_dmrplus_on->setVisible(false);
          ui->label_dmrplus_on->setVisible(false);
          ui->label_dmrplus_off->setVisible(true);
        }

    //BM
    ui->label_status_bm->setText(in.readLine());

    QString bm_status=ui->label_status_bm->text();

    if (bm_status.contains("MMDVMBM=ON")){
        ui->pushButton_bm_on->setVisible(true);
        ui->pushButton_bm_off->setVisible(false);
        ui->label_bm_on->setVisible(true);
        ui->label_bm_off->setVisible(false);

    }else {
          ui->pushButton_bm_off->setVisible(true);
          ui->pushButton_bm_on->setVisible(false);
          ui->label_bm_on->setVisible(false);
          ui->label_bm_off->setVisible(true);

  //SVXLINK
          ui->label_status_svxlink->setText(in.readLine());

          QString svxlink_status=ui->label_status_svxlink->text();

          if (svxlink_status.contains("SVXLINK=ON")){
              ui->pushButton_svxlink_on->setVisible(true);
              ui->pushButton_svxlink_off->setVisible(false);
              ui->label_svxlink_on->setVisible(true);
              ui->label_svxlink_off->setVisible(false);

          }else {
                ui->pushButton_svxlink_off->setVisible(true);
                ui->pushButton_svxlink_on->setVisible(false);
                ui->label_svxlink_on->setVisible(false);
                ui->label_svxlink_off->setVisible(true);
              }


          //dstarrepeater
                ui->label_status_dstarrepeater->setText(in.readLine());

                QString dstarrepeater_status=ui->label_status_dstarrepeater->text();

                if (dstarrepeater_status.contains("dstarrepeater=ON")){
                      ui->pushButton_dstarrepeater_on->setVisible(true);
                      ui->pushButton_dstarrepeater_off->setVisible(false);
                      ui->label_dstarrepeater_on->setVisible(true);
                      ui->label_dstarrepeater_off->setVisible(false);

                 }else {
                    ui->pushButton_dstarrepeater_on->setVisible(false);
                    ui->pushButton_dstarrepeater_off->setVisible(true);
                    ui->label_dstarrepeater_on->setVisible(false);
                    ui->label_dstarrepeater_off->setVisible(true);
                  }

    //ESPECIAL
     ui->label_status_especial->setText(in.readLine());
    QString especial_status=ui->label_status_especial->text();
    if (especial_status.contains("MMDVMLIBRE=ON")){
        ui->pushButton_especial_on->setVisible(true);
        ui->pushButton_especial_off->setVisible(false);
        ui->label_especial_on->setVisible(true);
        ui->label_especial_off->setVisible(false);

    }else {
          ui->pushButton_especial_off->setVisible(true);
          ui->pushButton_especial_on->setVisible(false);
          ui->label_especial_on->setVisible(false);
          ui->label_especial_off->setVisible(true);
        }

        }

    //SOLODSTAR
    ui->label_status_solodstar->setText(in.readLine());

    QString solodstar_status=ui->label_status_solodstar->text();

    if (solodstar_status.contains("SOLO_DSTAR=ON")){
        ui->pushButton_solodstar_on->setVisible(true);
        ui->pushButton_solodstar_off->setVisible(false);
        ui->label_solodstar_on->setVisible(true);
        ui->label_solodstar_off->setVisible(false);

    }else {
          ui->pushButton_solodstar_off->setVisible(true);
          ui->pushButton_solodstar_on->setVisible(false);
          ui->label_solodstar_on->setVisible(false);
          ui->label_solodstar_off->setVisible(true);
        }
    //SOLOFUSION
    ui->label_status_solofusion->setText(in.readLine());

    QString solofusion_status=ui->label_status_solofusion->text();

    if (solofusion_status.contains("SOLO_FUSION=ON")){
        ui->pushButton_solofusion_on->setVisible(true);
        ui->pushButton_solofusion_off->setVisible(false);
        ui->label_solofusion_on->setVisible(true);
        ui->label_solofusion_off->setVisible(false);

    }else {
          ui->pushButton_solofusion_off->setVisible(true);
          ui->pushButton_solofusion_on->setVisible(false);
          ui->label_solofusion_on->setVisible(false);
          ui->label_solofusion_off->setVisible(true);
        }
    //DVRPTR
    ui->label_status_dvrptr->setText(in.readLine());

    QString dvrptr_status=ui->label_status_dvrptr->text();

    if (dvrptr_status.contains("DVRPT=ON")){
        ui->pushButton_dvrptr_on->setVisible(true);
        ui->pushButton_dvrptr_off->setVisible(false);
        ui->label_dvrptr_on->setVisible(true);
        ui->label_dvrptr_off->setVisible(false);

    }else {
          ui->pushButton_dvrptr_off->setVisible(true);
          ui->pushButton_dvrptr_on->setVisible(false);
          ui->label_dvrptr_on->setVisible(false);
          ui->label_dvrptr_off->setVisible(true);
        }
    //AMBE_SERVER
    ui->label_status_ambe->setText(in.readLine());

    QString ambe_status=ui->label_status_ambe->text();

    if (ambe_status.contains("AMBE_SERVER=ON")){
        ui->pushButton_ambe_on->setVisible(true);
        ui->pushButton_ambe_off->setVisible(false);
        ui->label_ambe_on->setVisible(true);
        ui->label_ambe_off->setVisible(false);

    }else {
          ui->pushButton_ambe_off->setVisible(true);
          ui->pushButton_ambe_on->setVisible(false);
          ui->label_ambe_on->setVisible(false);
          ui->label_ambe_off->setVisible(true);
        }
    //YSF2DMR
    ui->label_status_ysf2dmr->setText(in.readLine());

    QString ysf2dmr_status=ui->label_status_ysf2dmr->text();

    if (ysf2dmr_status.contains("F2DMR=ON")){
        ui->pushButton_ysf2dmr_on->setVisible(true);
        ui->pushButton_ysf2dmr_off->setVisible(false);
        ui->label_ysf2dmr_on->setVisible(true);
        ui->label_ysf2dmr_off->setVisible(false);

    }else {
          ui->pushButton_ysf2dmr_off->setVisible(true);
          ui->pushButton_ysf2dmr_on->setVisible(false);
          ui->label_ysf2dmr_on->setVisible(false);
          ui->label_ysf2dmr_off->setVisible(true);
        }
    //DMR2YSF
    ui->label_status_dmr2ysf->setText(in.readLine());

    QString dmr2ysf_status=ui->label_status_dmr2ysf->text();

    if (dmr2ysf_status.contains("DMR2YSF=ON")){
        ui->pushButton_dmr2ysf_on->setVisible(true);
        ui->pushButton_dmr2ysf_off->setVisible(false);
        ui->label_dmr2ysf_on->setVisible(true);
        ui->label_dmr2ysf_off->setVisible(false);

    }else {
          ui->pushButton_dmr2ysf_off->setVisible(true);
          ui->pushButton_dmr2ysf_on->setVisible(false);
          ui->label_dmr2ysf_on->setVisible(false);
          ui->label_dmr2ysf_off->setVisible(true);
        }
    //DMR2NXDN
    ui->label_status_dmr2nxdn->setText(in.readLine());

    QString dmr2nxdn_status=ui->label_status_dmr2nxdn->text();

    if (dmr2nxdn_status.contains("DMR2NXDN=ON")){
        ui->pushButton_dmr2nxdn_on->setVisible(true);
        ui->pushButton_dmr2nxdn_off->setVisible(false);
        ui->label_dmr2nxdn_on->setVisible(true);
        ui->label_dmr2nxdn_off->setVisible(false);

    }else {
          ui->pushButton_dmr2nxdn_off->setVisible(true);
          ui->pushButton_dmr2nxdn_on->setVisible(false);
          ui->label_dmr2nxdn_on->setVisible(false);
          ui->label_dmr2nxdn_off->setVisible(true);
        }
    //NXDN
    ui->label_status_nxdn->setText(in.readLine());

    QString nxdn_status=ui->label_status_nxdn->text();

    if (nxdn_status.contains("NXDN=ON")){
        ui->pushButton_nxdn_on->setVisible(true);
        ui->pushButton_nxdn_off->setVisible(false);
        ui->label_nxdn_on->setVisible(true);
        ui->label_nxdn_off->setVisible(false);

    }else {
          ui->pushButton_nxdn_off->setVisible(true);
          ui->pushButton_nxdn_on->setVisible(false);
          ui->label_nxdn_on->setVisible(false);
          ui->label_nxdn_off->setVisible(true);
        }
    //DMRGATEWAY
    ui->label_status_dmrgateway->setText(in.readLine());

    QString dmrgateway_status=ui->label_status_dmrgateway->text();

    if (dmrgateway_status.contains("DMRGateway=ON")){
        ui->pushButton_dmrgateway_on->setVisible(true);
        ui->pushButton_dmrgateway_off->setVisible(false);
        ui->label_dmrgateway_on->setVisible(true);
        ui->label_dmrgateway_off->setVisible(false);

    }else {
          ui->pushButton_dmrgateway_off->setVisible(true);
          ui->pushButton_dmrgateway_on->setVisible(false);
          ui->label_dmrgateway_on->setVisible(false);
          ui->label_dmrgateway_off->setVisible(true);
        }
    //DMR2M17
    ui->label_status_dmr2m17->setText(in.readLine());

    QString dmr2m17_status=ui->label_status_dmr2m17->text();

    if (dmr2m17_status.contains("DMR2M17=ON")){
        ui->pushButton_dmr2m17_on->setVisible(true);
        ui->pushButton_dmr2m17_off->setVisible(false);
        ui->label_dmr2m17_on->setVisible(true);
        ui->label_dmr2m17_off->setVisible(false);

    }else {
          ui->pushButton_dmr2m17_off->setVisible(true);
          ui->pushButton_dmr2m17_on->setVisible(false);
          ui->label_dmr2m17_on->setVisible(false);
          ui->label_dmr2m17_off->setVisible(true);
        }

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_ircddb_on_clicked()
{
    system("sed -i '1c D-STAR=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/ircDDB.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_ircddb_on->setVisible(false);
    ui->pushButton_ircddb_off->setVisible(true);
    ui->label_ircddb_on->setVisible(false);
    ui->label_ircddb_off->setVisible(true);
}
void MainWindow::on_pushButton_ircddb_off_clicked()
{
    system("sed -i '1c D-STAR=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/ircDDB.desktop /home/orangepi/.config/autostart");
    ui->pushButton_ircddb_on->setVisible(true);
    ui->pushButton_ircddb_off->setVisible(false);
    ui->label_ircddb_on->setVisible(true);
    ui->label_ircddb_off->setVisible(false);
}


void MainWindow::on_pushButton_bluedv_on_clicked()
{
//    system("sed -i '2c BlueDV=OFF' /home/orangepi/autoarranque.ini");
//    system("rm /home/orangepi/.config/autostart/BLUEDV.desktop");
//    ui->pushButton_bluedv_on->setVisible(false);
//    ui->pushButton_bluedv_off->setVisible(true);
//    ui->label_bluedv_on->setVisible(false);
//    ui->label_bluedv_off->setVisible(true);
}

void MainWindow::on_pushButton_bluedv_off_clicked()
{
//    system("sed -i '2c BlueDV=ON' /home/orangepi/autoarranque.ini");
//    system("cp /home/orangepi/AUTOSTART/BLUEDV.desktop /home/orangepi/.config/autostart");
//    ui->pushButton_bluedv_on->setVisible(true);
//    ui->pushButton_bluedv_off->setVisible(false);
//    ui->label_bluedv_on->setVisible(true);
//    ui->label_bluedv_off->setVisible(false);
}

void MainWindow::on_pushButton_ysf_on_clicked()
{
    system("sed -i '3c C4F=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/YSF.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_ysf_on->setVisible(false);
    ui->pushButton_ysf_off->setVisible(true);
    ui->label_ysf_on->setVisible(false);
    ui->label_ysf_off->setVisible(true);
}
void MainWindow::on_pushButton_ysf_off_clicked()
{
    system("sed -i '3c C4F=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/YSF.desktop /home/orangepi/.config/autostart");
    ui->pushButton_ysf_on->setVisible(true);
    ui->pushButton_ysf_off->setVisible(false);
    ui->label_ysf_on->setVisible(true);
    ui->label_ysf_off->setVisible(false);
}


void MainWindow::on_pushButton_dv4mini_on_clicked()
{
    system("sed -i '4c DV4mini=OFF' /home/orangepi/autoarranque.ini");
    system("mv  /home/orangepi/.config/autostart/DV4mini.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_dv4mini_on->setVisible(false);
    ui->pushButton_dv4mini_off->setVisible(true);
    ui->label_dv4mini_on->setVisible(false);
    ui->label_dv4mini_off->setVisible(true);
}

void MainWindow::on_pushButton_dv4mini_off_clicked()
{
    system("sed -i '4c DV4mini=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/DV4mini.desktop /home/orangepi/.config/autostart");
    ui->pushButton_dv4mini_on->setVisible(true);
    ui->pushButton_dv4mini_off->setVisible(false);
    ui->label_dv4mini_on->setVisible(true);
    ui->label_dv4mini_off->setVisible(false);
}

void MainWindow::on_pushButton_radio_on_clicked()
{
    system("sed -i '5c MMDVMPLACA=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/RADIO.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_radio_on->setVisible(false);
    ui->pushButton_radio_off->setVisible(true);
    ui->label_radio_on->setVisible(false);
    ui->label_radio_off->setVisible(true);
}

void MainWindow::on_pushButton_radio_off_clicked()
{
    system("sed -i '5c MMDVMPLACA=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/RADIO.desktop /home/orangepi/.config/autostart");
    ui->pushButton_radio_on->setVisible(true);
    ui->pushButton_radio_off->setVisible(false);
    ui->label_radio_on->setVisible(true);
    ui->label_radio_off->setVisible(false);
}

void MainWindow::on_pushButton_dmrplus_on_clicked()
{
    system("sed -i '6c MMDVMPLUS=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/DMRPLUS.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_dmrplus_on->setVisible(false);
    ui->pushButton_dmrplus_off->setVisible(true);
    ui->label_dmrplus_on->setVisible(false);
    ui->label_dmrplus_off->setVisible(true);
}

void MainWindow::on_pushButton_dmrplus_off_clicked()
{
    system("sed -i '6c MMDVMPLUS=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/DMRPLUS.desktop /home/orangepi/.config/autostart");
    ui->pushButton_dmrplus_on->setVisible(true);
    ui->pushButton_dmrplus_off->setVisible(false);
    ui->label_dmrplus_on->setVisible(true);
    ui->label_dmrplus_off->setVisible(false);
}

void MainWindow::on_pushButton_salir_clicked()
{
    close();
}

void MainWindow::on_pushButton_especial_on_clicked()
{
    system("sed -i '10c MMDVMLIBRE=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/ESPECIAL.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_especial_on->setVisible(false);
    ui->pushButton_especial_off->setVisible(true);
    ui->label_especial_on->setVisible(false);
    ui->label_especial_off->setVisible(true);
}


void MainWindow::on_pushButton_especial_off_clicked()
{
    system("sed -i '10c MMDVMLIBRE=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/ESPECIAL.desktop /home/orangepi/.config/autostart");
    ui->pushButton_especial_on->setVisible(true);
    ui->pushButton_especial_off->setVisible(false);
    ui->label_especial_on->setVisible(true);
    ui->label_especial_off->setVisible(false);

}

void MainWindow::on_pushButton_bm_on_clicked()
{
    system("sed -i '7c MMDVMBM=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/BM.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_bm_on->setVisible(false);
    ui->pushButton_bm_off->setVisible(true);
    ui->label_bm_on->setVisible(false);
    ui->label_bm_off->setVisible(true);
}

void MainWindow::on_pushButton_bm_off_clicked()
{
    system("sed -i '7c MMDVMBM=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/BM.desktop /home/orangepi/.config/autostart");
    ui->pushButton_bm_on->setVisible(true);
    ui->pushButton_bm_off->setVisible(false);
    ui->label_bm_on->setVisible(true);
    ui->label_bm_off->setVisible(false);
}

void MainWindow::on_pushButton_svxlink_on_clicked()
{
    system("sed -i '8c SVXLINK=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/SVXLINK.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_svxlink_on->setVisible(false);
    ui->pushButton_svxlink_off->setVisible(true);
    ui->label_svxlink_on->setVisible(false);
    ui->label_svxlink_off->setVisible(true);
}

void MainWindow::on_pushButton_svxlink_off_clicked()
{
    system("sed -i '8c SVXLINK=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/SVXLINK.desktop /home/orangepi/.config/autostart");
    ui->pushButton_svxlink_on->setVisible(true);
    ui->pushButton_svxlink_off->setVisible(false);
    ui->label_svxlink_on->setVisible(true);
    ui->label_svxlink_off->setVisible(false);
}

void MainWindow::on_pushButton_solodstar_on_clicked()
{
    system("sed -i '11c SOLO_DSTAR=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/DSTARSOLO.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_solodstar_on->setVisible(false);
    ui->pushButton_solodstar_off->setVisible(true);
    ui->label_solodstar_on->setVisible(false);
    ui->label_solodstar_off->setVisible(true);
}

void MainWindow::on_pushButton_solodstar_off_clicked()
{
    system("sed -i '11c SOLO_DSTAR=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/DSTARSOLO.desktop /home/orangepi/.config/autostart");
    ui->pushButton_solodstar_on->setVisible(true);
    ui->pushButton_solodstar_off->setVisible(false);
    ui->label_solodstar_on->setVisible(true);
    ui->label_solodstar_off->setVisible(false);
}

void MainWindow::on_pushButton_solofusion_on_clicked()
{
    system("sed -i '12c SOLO_FUSION=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/FUSIONSOLO.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_solofusion_on->setVisible(false);
    ui->pushButton_solofusion_off->setVisible(true);
    ui->label_solofusion_on->setVisible(false);
    ui->label_solofusion_off->setVisible(true);
}

void MainWindow::on_pushButton_solofusion_off_clicked()
{
    system("sed -i '12c SOLO_FUSION=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/FUSIONSOLO.desktop /home/orangepi/.config/autostart");
    ui->pushButton_solofusion_on->setVisible(true);
    ui->pushButton_solofusion_off->setVisible(false);
    ui->label_solofusion_on->setVisible(true);
    ui->label_solofusion_off->setVisible(false);
}

void MainWindow::on_pushButton_dvrptr_on_clicked()
{
    system("sed -i '13c DVRPTR=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/DVRPTR.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_dvrptr_on->setVisible(false);
    ui->pushButton_dvrptr_off->setVisible(true);
    ui->label_dvrptr_on->setVisible(false);
    ui->label_dvrptr_off->setVisible(true);
}

void MainWindow::on_pushButton_dvrptr_off_clicked()
{
    system("sed -i '13c DVRPTR=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/DVRPTR.desktop /home/orangepi/.config/autostart");
    ui->pushButton_dvrptr_on->setVisible(true);
    ui->pushButton_dvrptr_off->setVisible(false);
    ui->label_dvrptr_on->setVisible(true);
    ui->label_dvrptr_off->setVisible(false);
}

void MainWindow::on_pushButton_ambe_on_clicked()
{
    system("sed -i '14c AMBE_SERVER=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/AMBESERVER.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_ambe_on->setVisible(false);
    ui->pushButton_ambe_off->setVisible(true);
    ui->label_ambe_on->setVisible(false);
    ui->label_ambe_off->setVisible(true);
}

void MainWindow::on_pushButton_ambe_off_clicked()
{
    system("sed -i '14c AMBE_SERVER=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/AMBESERVER.desktop /home/orangepi/.config/autostart");
    ui->pushButton_ambe_on->setVisible(true);
    ui->pushButton_ambe_off->setVisible(false);
    ui->label_ambe_on->setVisible(true);
    ui->label_ambe_off->setVisible(false);
}

void MainWindow::on_pushButton_ysf2dmr_on_clicked()
{
    system("sed -i '15c F2DMR=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/YSF2DMR.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_ysf2dmr_on->setVisible(false);
    ui->pushButton_ysf2dmr_off->setVisible(true);
    ui->label_ysf2dmr_on->setVisible(false);
    ui->label_ysf2dmr_off->setVisible(true);
}

void MainWindow::on_pushButton_ysf2dmr_off_clicked()
{
    system("sed -i '15c F2DMR=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/YSF2DMR.desktop /home/orangepi/.config/autostart");
    ui->pushButton_ysf2dmr_on->setVisible(true);
    ui->pushButton_ysf2dmr_off->setVisible(false);
    ui->label_ysf2dmr_on->setVisible(true);
    ui->label_ysf2dmr_off->setVisible(false);
}

void MainWindow::on_pushButton_dmr2ysf_on_clicked()
{
    system("sed -i '16c DMR2YSF=OFF' /home/orangepi/autoarranque.ini");
    system("mv/home/orangepi/.config/autostart/DMR2YSF.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_dmr2ysf_on->setVisible(false);
    ui->pushButton_dmr2ysf_off->setVisible(true);
    ui->label_dmr2ysf_on->setVisible(false);
    ui->label_dmr2ysf_off->setVisible(true);
}

void MainWindow::on_pushButton_dmr2ysf_off_clicked()
{
    system("sed -i '16c DMR2YSF=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/DMR2YSF.desktop /home/orangepi/.config/autostart");
    ui->pushButton_dmr2ysf_on->setVisible(true);
    ui->pushButton_dmr2ysf_off->setVisible(false);
    ui->label_dmr2ysf_on->setVisible(true);
    ui->label_dmr2ysf_off->setVisible(false);
}

void MainWindow::on_pushButton_dmr2nxdn_on_clicked()
{
    system("sed -i '17c NXDN=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/DMR2NXDN.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_dmr2nxdn_on->setVisible(false);
    ui->pushButton_dmr2nxdn_off->setVisible(true);
    ui->label_dmr2nxdn_on->setVisible(false);
    ui->label_dmr2nxdn_off->setVisible(true);
}

void MainWindow::on_pushButton_dmr2nxdn_off_clicked()
{
    system("sed -i '17c NXDN=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/DMR2NXDN.desktop /home/orangepi/.config/autostart");
    ui->pushButton_dmr2nxdn_on->setVisible(true);
    ui->pushButton_dmr2nxdn_off->setVisible(false);
    ui->label_dmr2nxdn_on->setVisible(true);
    ui->label_dmr2nxdn_off->setVisible(false);
}

void MainWindow::on_pushButton_nxdn_on_clicked()
{
//     system("sed -i '17c NXDN=OFF' /home/orangepi/autoarranque.ini");
//    system("rm /home/orangepi/.config/autostart/NXDN.desktop");
//    ui->pushButton_nxdn_on->setVisible(false);
//    ui->pushButton_nxdn_off->setVisible(true);
//    ui->label_nxdn_on->setVisible(false);
//    ui->label_nxdn_off->setVisible(true);
}

void MainWindow::on_pushButton_nxdn_off_clicked()
{
//    system("sed -i '17c NXDN=ON' /home/orangepi/autoarranque.ini");
//    system("cp /home/orangepi/AUTOSTART/NXDN.desktop /home/orangepi/.config/autostart");
//    ui->pushButton_nxdn_on->setVisible(true);
//    ui->pushButton_nxdn_off->setVisible(false);
//    ui->label_nxdn_on->setVisible(true);
//    ui->label_nxdn_off->setVisible(false);
}

void MainWindow::on_pushButton_dmrgateway_on_clicked()
{
//    system("sed -i '18c DMRGateway=OFF' /home/orangepi/autoarranque.ini");
//    system("rm /home/orangepi/.config/autostart/DMRGateway.desktop");
//    ui->pushButton_dmrgateway_on->setVisible(false);
//    ui->pushButton_dmrgateway_off->setVisible(true);
//    ui->label_dmrgateway_on->setVisible(false);
//    ui->label_dmrgateway_off->setVisible(true);
}

void MainWindow::on_pushButton_dmrgateway_off_clicked()
{
//    system("sed -i '18c DMRGateway=ON' /home/orangepi/autoarranque.ini");
//    system("cp /home/orangepi/AUTOSTART/DMRGateway.desktop /home/orangepi/.config/autostart");
//    ui->pushButton_dmrgateway_on->setVisible(true);
//    ui->pushButton_dmrgateway_off->setVisible(false);
//    ui->label_dmrgateway_on->setVisible(true);
//    ui->label_dmrgateway_off->setVisible(false);
}

void MainWindow::on_pushButton_dmr2m17_on_clicked()
{
//    system("sed -i '19c DMR2M17=OFF' /home/orangepi/autoarranque.ini");
//    system("rm /home/orangepi/.config/autostart/DMR2M17.desktop");
//    ui->pushButton_dmr2m17_on->setVisible(false);
//    ui->pushButton_dmr2m17_off->setVisible(true);
//    ui->label_dmr2m17_on->setVisible(false);
//    ui->label_dmr2m17_off->setVisible(true);
}

void MainWindow::on_pushButton_dmr2m17_off_clicked()
{
//    system("sed -i '19c DMR2M17=ON' /home/orangepi/autoarranque.ini");
//    system("cp /home/orangepi/AUTOSTART/DMR2M17.desktop /home/orangepi/.config/autostart");
//    ui->pushButton_dmr2m17_on->setVisible(true);
//    ui->pushButton_dmr2m17_off->setVisible(false);
//    ui->label_dmr2m17_on->setVisible(true);
//    ui->label_dmr2m17_off->setVisible(false);
}

void MainWindow::on_pushButton_m17_on_2_clicked()
{

}

void MainWindow::on_pushButton_dump1090_off_clicked()
{
    system("sed -i '2c DUMP1090=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/dump1090.desktop /home/orangepi/.config/autostart");
    ui->pushButton_dump1090_on->setVisible(true);
    ui->pushButton_dump1090_off->setVisible(false);
    ui->label_dump1090_on->setVisible(true);
    ui->label_dump1090_off->setVisible(false);
}

void MainWindow::on_pushButton_dump1090_on_clicked()
{
    system("sed -i '2c DUMP1090=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/dump1090.desktop home/orangepi/AUTOSTART");
    ui->pushButton_dump1090_on->setVisible(false);
    ui->pushButton_dump1090_off->setVisible(true);
    ui->label_dump1090_on->setVisible(false);
    ui->label_dump1090_off->setVisible(true);
}

void MainWindow::on_pushButton_dstarrepeater_off_clicked()
{
    system("sed -i '9c dstarrepeater=ON' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/AUTOSTART/dstarrepeater.desktop /home/orangepi/.config/autostart");
    ui->pushButton_dstarrepeater_on->setVisible(true);
    ui->pushButton_dstarrepeater_off->setVisible(false);
    ui->label_dstarrepeater_on->setVisible(true);
    ui->label_dstarrepeater_off->setVisible(false);
}

void MainWindow::on_pushButton_dstarrepeater_on_clicked()
{
    system("sed -i '9c dstarrepeater=OFF' /home/orangepi/autoarranque.ini");
    system("mv /home/orangepi/.config/autostart/dstarrepeater.desktop /home/orangepi/AUTOSTART");
    ui->pushButton_dstarrepeater_on->setVisible(false);
    ui->pushButton_dstarrepeater_off->setVisible(true);
    ui->label_dstarrepeater_on->setVisible(false);
    ui->label_dstarrepeater_off->setVisible(true);
}
