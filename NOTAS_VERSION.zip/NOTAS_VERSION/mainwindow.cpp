#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "QFile"
#include "QMessageBox"
#include "QTextStream"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);



    // la linea siguiente oculta toda la barra superior del formulario
    setWindowFlags(Qt::Window | Qt::CustomizeWindowHint);

    // POSICION DEL FORMULARIO EN LA PANTALLA
    int px  = (22);
    int py = (517);
    this->move(   QPoint(px,py)  );

    QFile file2("/home/orangepi/.local/info.txt");
    if (!file2.open(QIODevice::ReadOnly))
    QMessageBox::information(nullptr,"info", file2.errorString());
    QTextStream in2(&file2);
    ui->label_info->setText(in2.readLine());
    QString info=ui->label_info->text();
    info.remove(0,12);
    ui->label_info->setText(info);
    QFile file3("/home/orangepi/MMDVMHost/Version.h");
    if (!file3.open(QIODevice::ReadOnly))
    QMessageBox::information(nullptr,"info", file3.errorString());
    QTextStream in3(&file3);
    for (int i = 1; i <= 22; ++i) {
    ui->label_fecha_mmdvm->setText(in3.readLine());}

    QString version=ui->label_fecha_mmdvm->text();
    version.remove(0,23);
    QString version1=version;
    ui->label_fecha_mmdvm->setText(version);

    //Rutina de transformar fecha inglesa a española
    QString version2=version1;
    version2.remove(8,10);// 20210116
    QString ano=version2;
    ano.remove(4,4);//2021
    QString mes1=version2;
    mes1.remove(0,4);//0116
    QString mes=mes1;
    mes.remove(2,2);//01
    QString dia=version2;
    dia.remove(0,6);//16
    QString fecha=dia + "-" + mes + "-" + ano;
    ui->label_fecha_mmdvm->setText(fecha);

    QFile file4("/sys/class/thermal/thermal_zone0/temp");
    if (!file4.open(QIODevice::ReadOnly))
    QMessageBox::information(nullptr,"info", file4.errorString());
    QTextStream in4(&file4);

    // Rutina para presentar los grados de la raspi

    ui->label_temperatura->setText(in4.readLine());
    QString grados1=ui->label_temperatura->text();
    grados1.remove(2,3);
    QString grados = grados1 + " Grados";
    ui->label_temperatura->setText(grados);


    // Fecha de la imagen
    QFile file1("/home/orangepi/version-fecha-actualizacion");
    if (!file1.open(QIODevice::ReadOnly))
    QMessageBox::information(nullptr,"info", file1.errorString());
    QTextStream in1(&file1);
    ui->label_actualizacion->setText(in1.readLine());

    // Fecha actualizacion
    for (int i = 1; i <= 1; ++i) {
    ui->label_fecha_actualizacion->setText(in1.readLine());}

    // Versión
    for (int i = 1; i <= 1; ++i) {      
    ui->label_version->setText(in1.readLine());}

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    close();
}

void MainWindow::on_pushButton_on_clicked()
{
    system("cd /home/orangepi/ORANGEPI; xterm -geometry 86x23+24+562 -bg black -fg white -fa 'verdana' -fs 9x -T INFO -e sh neofetch.sh &");
    ui->pushButton_on->setVisible(false);
}
